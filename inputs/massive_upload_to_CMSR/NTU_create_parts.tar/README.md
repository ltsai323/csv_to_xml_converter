All of historical data sent to George for INT2R -> CMSR migration.

# csv files

csv files recorded the received bare hexaboards and assembled hexaboards.
Containing the visual inspection data. These csv files are raw data recorded from NTU MAC.

# xml_* folders

These folder record the generated xml files from csv raw data.
The xml files inside folder are ready for database creating parts.

Note that these xml files are used for create parts, not visual inspection.

# record_HGCROC.txt and record_LDO.txt

These two text files lists all of assembled LDOs and HGCROCs ID.
However, v3A HGCROC lacks of barcode, so we recorded the word on these HGCROC: 2120-KOR

